const express = require("express");
const workerController = require("../controllers/workerController");
const router = express.Router();

router.get("/dashboard", workerController.getDashboard);
router.get("/profile", workerController.getProfile);
router.get("/jobs", workerController.searchJobs);

module.exports = router;
