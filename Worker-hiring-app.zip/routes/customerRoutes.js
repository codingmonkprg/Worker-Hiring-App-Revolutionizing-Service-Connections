const express = require("express");
const customerController = require("../controllers/customerController");
const router = express.Router();

router.get("/dashboard", customerController.getDashboard);
router.post("/post-job", customerController.postJob);
router.get("/job-applicants", customerController.getJobApplicants);

module.exports = router;
