const express = require("express");
const adminController = require("../controllers/adminController");
const router = express.Router();

router.get("/dashboard", adminController.getDashboard);
router.get("/manage-users", adminController.manageUsers);
router.get("/manage-jobs", adminController.manageJobs);

module.exports = router;
