const User = require("../models/User");

exports.signup = async (req, res) => {
    // Signup logic with ID proof verification
};

exports.login = async (req, res) => {
    // Login logic based on user role, redirecting to respective dashboard
};
