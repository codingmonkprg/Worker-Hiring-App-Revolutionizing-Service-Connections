<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Worker Hiring App</title>
    <link rel="stylesheet" href="/style.css"> <!-- Link to your CSS file if needed -->
    <style>
        .cards {
            display: flex;
            gap: 20px;
        }
        .card img {
            width: 150px;
            height: 100px;
        }
    </style>
</head>
<body>
    <section class="cards">
        <div class="card">
            <img id="construction-img" src="images/image1.png" alt="Construction Work" />
            <h3>Construction Work</h3>
            <p>Find skilled construction workers for your projects.</p>
        </div>
        <div class="card">
            <img id="maintenance-img" src="images/image1.png" alt="Home Maintenance" /> 
            <h3>Home Maintenance</h3>
            <p>Hire for household maintenance and repair work.</p>
        </div>
        <div class="card">
            <img id="carpentry-img" src="images/image1.png" alt="Carpentry" />
            <h3>Carpentry</h3>
            <p>Experienced carpenters available for hire.</p>
        </div>
    </section>

    <script>
        // Array of image paths
        const images = [
            "/images/image (1).png",
            "/images/image (2).png",
            "/images/image (3).png",
            "/images/image (4).png",
            "/images/image (5).png",
            "/images/image (6).png",
            "/images/image (7).png",
            "/images/image (8).png",
            "/images/image (9).png",
            // Add more images as needed
        ];

        // Starting index
        let currentIndex = 0;

        // Function to update images
        function updateImages() {
            // Update each card image
            document.getElementById("construction-img").src = images[currentIndex];
            document.getElementById("maintenance-img").src = images[(currentIndex + 1) % images.length];
            document.getElementById("carpentry-img").src = images[(currentIndex + 2) % images.length];

            // Increment the index and reset if it exceeds the array length
            currentIndex = (currentIndex + 1) % images.length;
        }

        // Set interval for updating images
        setInterval(updateImages, 3000); // Update every 3 seconds
    </script>
</body>
</html>
