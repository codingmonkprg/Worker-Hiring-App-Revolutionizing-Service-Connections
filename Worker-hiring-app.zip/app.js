require("dotenv").config(); // Load environment variables from .env file
const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const authRoutes = require("./routes/authRoutes");
const workerRoutes = require("./routes/workerRoutes");
const customerRoutes = require("./routes/customerRoutes");
const adminRoutes = require("./routes/adminRoutes");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// Session setup for login persistence
app.use(
    session({
        secret: "your_secret_key",
        resave: false,
        saveUninitialized: true,
    }),
);

// Log the MongoDB URI to check if it's being read correctly
console.log("MongoDB URI:", process.env.MONGODB_URI); // Log to check if the URI is loaded

// Database Connection
mongoose
    .connect(process.env.MONGODB_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then(() => {
        console.log("MongoDB connected.");
    })
    .catch((err) => console.log("DB connection error:", err));

// Define a route for the root URL
const path = require("path");

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "index.html"));
});

// Route Middleware
app.use("/auth", authRoutes);
app.use("/worker", workerRoutes);
app.use("/customer", customerRoutes);
app.use("/admin", adminRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
